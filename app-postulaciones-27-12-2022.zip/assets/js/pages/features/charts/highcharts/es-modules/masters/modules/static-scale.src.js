/**
 * @license Highcharts Gantt JS v10.2.0 (2022-07-05)
 * @module highcharts/modules/static-scale
 * @requires highcharts
 *
 * StaticScale
 *
 * (c) 2016-2021 Torstein Honsi, Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/StaticScale.js';
