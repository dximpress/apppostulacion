/**
 * @license Highcharts JS v10.2.0 (2022-07-05)
 * @module highcharts/modules/wordcloud
 * @requires highcharts
 *
 * (c) 2016-2021 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/Wordcloud/WordcloudSeries.js';
